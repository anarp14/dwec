import './App.css';

function formatDate(date) {
  return (date.toLocaleDateString());
}

export function App(props){
  return(
    <div className="App">
      <div className='UserInfo'>
        <img className='Avatar'
          src={props.author.avatarUrl}
          alt={props.author.name}/>
        <div className='UserInfo-name'>
          {props.author.name}
        </div>
      </div>
      <div className='Comment-text'>
        {props.text}
      </div>
      <div className='Comment-date'>
        {formatDate(props.date)}
      </div>
    </div>
  );
}
