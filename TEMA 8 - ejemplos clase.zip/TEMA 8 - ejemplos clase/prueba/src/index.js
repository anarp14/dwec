import React from 'react';
import ReactDOM from 'react-dom/client';
import  { App } from './App';
import reportWebVitals from './reportWebVitals';


const comment = {
  date: new Date(),
  text: 'I hope you enjoy learning React!',
  author:{
  name: 'Hello',
  avatarUrl: 'https://img2.rtve.es/imagenes/this-is-not-fine-segunda-parte-famosa-tira-comica-kc-green/1614358629008.png'
  }
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App
  date = {comment.date}
  text = {comment.text}
  author = {comment.author} />
  </React.StrictMode>
);


reportWebVitals();
