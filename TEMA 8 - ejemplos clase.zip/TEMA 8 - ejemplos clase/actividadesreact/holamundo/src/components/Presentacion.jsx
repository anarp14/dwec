import React from "react";
import imagennueva from "../assets/perro.jpeg"
import '../presentacion.css';

function Presentacion(){
    let name="Ana Rodriguez"
    return(
        <div className="Presentacion">
            <img src={imagennueva} alt="Imag" className="imagenperro"/>
            <h1>
                Hola este es mi primer componente <br/>
                Soy {name}
            </h1>
        </div>
    )
}

export default Presentacion;
