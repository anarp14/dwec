import './App.css'
import Boton from './components/Boton'

function App() {

  return (
      <Boton/>
  )
}

export default App
