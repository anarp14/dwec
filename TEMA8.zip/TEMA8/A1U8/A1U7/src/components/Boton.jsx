import React, { useState } from 'react';

/*
Creamos un componente de función llamado Boton que usa el hook useState para inicializar el estado contador a 0.
Luego, definimos una función llamada handleClick que actualiza el estado contador sumando 1 cada vez que se pulsa el botón.
Finalmente, en la interfaz de usuario, mostramos el valor actual de contador y hacemos que el botón llame a handleClick cuando se pulsa.
Puedes escribir tantas líneas como necesites.
*/

/*
El hook useState retorna un array con dos elementos:

El primer elemento es el valor actual del estado.
El segundo elemento es una función que se utiliza para actualizar el estado.
*/


function Boton() {
    const [contador, setContador] = useState(0); //useState(0) es una llamada al hook useState que inicializa el estado a un valor de 0.

    /*
    En la función handleClick que se ejecuta cuando se hace clic en el botón, estamos utilizando setContador para actualizar el valor del estado.
    */
    const handleClick = () => {
      setContador(contador + 1);
    }

    return (
      <div>
        <p>Contador: {contador}</p>
        <button onClick={handleClick}>Pulsar botón</button>
      </div>
    );
  }

  export default Boton;
