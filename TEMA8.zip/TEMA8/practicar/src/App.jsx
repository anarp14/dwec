import Ejemplo from '../src/components/Ejemplo'
import './App.css'

function App() {
 return (
  <div>
    <Ejemplo/>
  </div>
 )
}

export default App
