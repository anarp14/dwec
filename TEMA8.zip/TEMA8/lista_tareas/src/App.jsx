import Tareas from './components/Tareas'
import './App.css'

function App() {

  return (

      <Tareas/>


  )
}

export default App
