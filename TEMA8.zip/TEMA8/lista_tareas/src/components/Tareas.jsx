import React, { useState } from "react";

function ListaTareas() {
  const [tareas, setTareas] = useState([]); // se define el estado inicial de la aplicación, una lista vacía de tareas.

  // Función para agregar una tarea : La función recibe un evento (que se utiliza para prevenir el comportamiento por defecto del formulario) y lee el valor del campo de texto donde se ingresa la tarea.
  function agregarTarea(evento) {
    evento.preventDefault();
    const nuevaTarea = evento.target.tarea.value;
    setTareas([...tareas, nuevaTarea]); //crea una nueva lista de tareas mediante la propagación de la lista anterior y agrega la nueva tarea al final de la lista.
    evento.target.tarea.value = "";     //utiliza la función setTareas para actualizar el estado y vacía el campo de texto del formulario.
  }

  // Función para eliminar una tarea
  function eliminarTarea(index) {        // La función recibe el índice de la tarea que se desea eliminar y crea una nueva lista de tareas mediante la propagación de la lista anterior y eliminando la tarea correspondiente con el método splice().
    const nuevasTareas = [...tareas];
    nuevasTareas.splice(index, 1);
    setTareas(nuevasTareas);
  }

  return (
    <div>
      <h1>Lista de Tareas</h1>
      <form onSubmit={agregarTarea}>
        <input type="text" name="tarea" />
        <button>Agregar Tarea</button>
      </form>
      <ul>
        {tareas.map((tarea, index) => (
          <li key={index}>
            {tarea} <button onClick={() => eliminarTarea(index)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ListaTareas;
