import { useState, useEffect } from "react";

function Temporizador() {
  // Estado para el número de segundos a contar
  const [segundosObjetivo, setSegundosObjetivo] = useState(null);
  // Estado para el número de segundos transcurridos
  const [segundosTranscurridos, setSegundosTranscurridos] = useState(0);

  // Efecto para iniciar el temporizador cuando el usuario establece un número de segundos
  useEffect(() => {
    // Si no se ha establecido un número de segundos, no hagas nada
    if (segundosObjetivo === null) return;

    // Inicializa el temporizador
    setSegundosTranscurridos(0);
    const interval = setInterval(() => {
      setSegundosTranscurridos((segundosTranscurridos) => segundosTranscurridos + 1);
    }, 1000);


    // Limpia el temporizador cuando el componente se desmonta o cuando se establece un nuevo número de segundos
    return () => clearInterval(interval);
  }, [segundosObjetivo]);

  // Función para manejar el envío del formulario y establecer el número de segundos a contar
  function manejarFormulario(ev) {
    ev.preventDefault();
    const segundos = ev.target.segundos.value;
    setSegundosObjetivo(parseInt(segundos));
  }

  // Mostrar el mensaje de temporizador cuando se alcanza el número de segundos objetivo
  if (segundosTranscurridos >= segundosObjetivo && segundosObjetivo !== null) {
    return (
      <>
        <h1>Temporizador</h1>
        <img src="../../public/reloj.png" alt="Reloj" width="40%" />
        <p>SE HA TERMINADO EL TIEMPO</p>
        <button onClick={() => setSegundosObjetivo(null)}>REINICIAR</button>
      </>
    );
  }

  // Mostrar el temporizador mientras se está contando
  if (segundosObjetivo !== null) {
    return (
      <>
        <h1>Temporizador</h1>
        <img src="../../public/reloj.png" alt="Reloj" width="40%" />
        <p>
          Soy un conteo hasta el {segundosObjetivo} y han transcurrido{" "}
          {segundosTranscurridos} segundos <br/> <br/>

          QUEDAN: {segundosObjetivo - segundosTranscurridos} segundos
        </p>
      </>
    );
  }

  // Mostrar el formulario para establecer el número de segundos
  return (
    <>
      <h1>Temporizador</h1>
      <img src="../../public/reloj.png" alt="Reloj" width="40%" />
      <p>¿Cuántos segundos vamos a contar?</p>
      <form onSubmit={manejarFormulario}>
        <input type="number" name="segundos" /> <button>iniciar</button>
      </form>
    </>
  );
}

export default Temporizador;
