import Temporizador from './components/Temporizador'
import './App.css'

function App() {

  return (
    <div className="App">
      <Temporizador/>
    </div>

  )
}

export default App
