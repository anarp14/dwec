import React from 'react';
import Semaforo from './components/Semaforo';
import './App.css';

function App() {
  return (
    <div className="container">
      <Semaforo />
    </div>
  );
}

export default App;
