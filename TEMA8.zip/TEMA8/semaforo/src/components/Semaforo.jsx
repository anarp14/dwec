import React, { useState, useEffect } from "react";
import "../semaforo.css";

function Semaforo() {
    const [color, setColor] = useState("red");
    const [activarVerde, setActivarVerde] = useState(false);

    useEffect(() => {
        const interval = setInterval(() => {
            if (activarVerde) {
                setColor("green");
                setTimeout(() => {
                    setColor("yellow");
                }, 3000); // Cambia a amarillo después de 3 segundos
                setActivarVerde(false);
            } else {
                if (color === "red") {
                    setColor("green");
                } else if (color === "green") {
                    setColor("yellow");
                } else if (color === "yellow") {
                    setColor("red");
                }
            }
        }, 4000); // Cambia de color cada 2 segundos

        return () => clearInterval(interval);
    }, [color, activarVerde]);

    function cambiarColor() {
        if (color === "red") {
            setColor("green");
        } else if (color === "green") {
            setColor("yellow");
        } else if (color === "yellow") {
            setColor("red");
        }
    }

    function activarSemaforo() {
        setActivarVerde(true);
    }

    return (
        <div>
            <div
                className="luz-roja"
                style={{ backgroundColor: color === "red" ? "red" : "gray" }}
            ></div>
            <div
                className="luz-amarilla"
                style={{ backgroundColor: color === "yellow" ? "yellow" : "gray" }}
            ></div>
            <div
                className="luz-verde"
                style={{ backgroundColor: color === "green" ? "green" : "gray" }}
            ></div>
            <br />
            <button onClick={cambiarColor}>Cambiar color</button><br/><br/>
            <button onClick={activarSemaforo}>Activar semáforo</button>
        </div>
    );
}

export default Semaforo;


// import React, { useState, useEffect } from "react";
// import "./Semaforo.css";

// function Semaforo() {
//   const [color, setColor] = useState("red");

//   useEffect(() => {
//     const interval = setInterval(() => {
//       if (color === "red") {
//         setColor("green");
//       } else if (color === "green") {
//         setColor("yellow");
//       } else if (color === "yellow") {
//         setColor("red");
//       }
//     }, 2000); // Cambia de color cada 2 segundos

//     return () => clearInterval(interval);
//   }, [color]);

//   function cambiarColor() {
//     if (color === "red") {
//       setColor("green");
//     } else if (color === "green") {
//       setColor("yellow");
//     } else if (color === "yellow") {
//       setColor("red");
//     }
//   }

//   return (
//     <div>
//       <div
//         className="luz-roja"
//         style={{ backgroundColor: color === "red" ? "red" : "gray" }}
//       ></div>
//       <div
//         className="luz-amarilla"
//         style={{ backgroundColor: color === "yellow" ? "yellow" : "gray" }}
//       ></div>
//       <div
//         className="luz-verde"
//         style={{ backgroundColor: color === "green" ? "green" : "gray" }}
//       ></div>
//       <button onClick={cambiarColor}>Cambiar color</button>
//     </div>
//   );
// }

// export default Semaforo;
